
#ifndef SCPI_EXPORT_H
#define SCPI_EXPORT_H

#ifdef SCPI_STATIC_DEFINE
#  define SCPI_EXPORT
#  define SCPI_NO_EXPORT
#else
#  ifndef SCPI_EXPORT
#    ifdef scpi_EXPORTS
        /* We are building this library */
#      define SCPI_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define SCPI_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef SCPI_NO_EXPORT
#    define SCPI_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef SCPI_DEPRECATED
#  define SCPI_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef SCPI_DEPRECATED_EXPORT
#  define SCPI_DEPRECATED_EXPORT SCPI_EXPORT SCPI_DEPRECATED
#endif

#ifndef SCPI_DEPRECATED_NO_EXPORT
#  define SCPI_DEPRECATED_NO_EXPORT SCPI_NO_EXPORT SCPI_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef SCPI_NO_DEPRECATED
#    define SCPI_NO_DEPRECATED
#  endif
#endif

#endif /* SCPI_EXPORT_H */
